#BellP5 - Supplemental
#purpose - To learn to define classes as single files, for import as library.

from PySide6.QtWidgets import QMessageBox, QApplication
import csv
global courses

errorWindow = QApplication

class Course:
    # Represents a single course.
    def __init__(self, course_id, course_name, crn, instructor):
        self.course_id = course_id
        self.course_name = course_name
        self.crn = crn
        self.instructor = instructor

    def __str__(self):
        # instructs python HOW to return a string of our course.
        return f"{self.course_id}: {self.course_name} (CRN: {self.crn}, Instructor: {self.instructor})"
    @staticmethod
    def load_courses_from_csv(file_path):
        try:
            courses = []
            with open(file_path, newline='') as csvfile:
                reader = csv.DictReader(csvfile)
                
                #Validate headers are good
                csvMustContain = {'course_id', 'course_name', 'crn', 'instructor'}
                if not csvMustContain.issubset(reader.fieldnames):
                    raise ValueError(f"Malformed CSV, missing column(s): {csvMustContain - set(reader.fieldnames)}")
                
                for row in reader:
                    courses.append(Course(row['course_id'], row['course_name'], row['crn'], row['instructor']))
            return courses                   
        except (FileNotFoundError, csv.Error, KeyError, ValueError) as e:
            errorMessage = QMessageBox()
            errorMessage.setIcon(QMessageBox.Critical)
            errorMessage.setWindowTitle("Error")
            errorMessage.setText("Possible failed to load courses")
            errorMessage.setInformativeText(str(e))
            errorMessage.exec()            
            return []
